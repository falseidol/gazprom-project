package ru.practicum.shareit.exception;

public class BebraException extends RuntimeException {
    public BebraException(String message) {
        super(message);
    }
}