package ru.practicum.shareit.utils;

public interface Create {
}