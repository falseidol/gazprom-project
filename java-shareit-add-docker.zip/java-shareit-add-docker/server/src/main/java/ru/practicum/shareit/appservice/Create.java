package ru.practicum.shareit.appservice;

public interface Create {
}